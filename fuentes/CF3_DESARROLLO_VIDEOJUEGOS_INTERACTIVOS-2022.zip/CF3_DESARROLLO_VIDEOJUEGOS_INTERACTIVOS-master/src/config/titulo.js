module.exports = 'Animación y edición de sonidos'
